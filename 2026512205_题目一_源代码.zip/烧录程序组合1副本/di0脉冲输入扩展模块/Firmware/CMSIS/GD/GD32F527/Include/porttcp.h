/* porttcp.h - TCP ������������ */
#ifndef _PORTTCP_H
#define _PORTTCP_H

#include <stdint.h>

struct tcp_pcb;

#ifdef __cplusplus
extern "C" {
#endif

void mb_tcp_recv_input(struct tcp_pcb *pcb, uint8_t *data, uint16_t len);
void mb_tcp_client_disconnect(void);

#ifdef __cplusplus
}
#endif

#endif /* _PORTTCP_H */
