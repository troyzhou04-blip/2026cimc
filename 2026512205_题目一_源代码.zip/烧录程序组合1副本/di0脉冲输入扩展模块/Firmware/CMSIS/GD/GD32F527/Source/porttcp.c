/* porttcp.c - FreeModbus Porting Implementation for GD32F527 + LwIP
 *
 * TCP porting: fully implemented here.
 * RTU/RS-485 porting: USART5 interrupt handlers moved to rtu_master.c
 *   to avoid symbol conflicts. The RTU master owns USART5 entirely.
 */
#include <string.h>
#include "mbport.h"
#include "porttcp.h"
#include "gd32f527.h"
#include "mbconfig.h"

/* RTU callback pointers - not used in TCP-only mode, kept for compatibility */
BOOL (*pxMBPortCBRxCharAvail)(UCHAR ucChar) = NULL;
BOOL (*pxMBPortCBTxEmpty)(void) = NULL;
extern BOOL (*pxMBPortCBTimerExpired)(void);

/* ========== ȫ�ֱ��� ========== */
static struct tcp_pcb *current_client_pcb = NULL;
static UCHAR tcp_recv_buf[300];
static USHORT tcp_recv_len = 0;

static volatile eMBEventType g_mb_event = EV_READY;

/* ========== RS-485 ����������� ========== */
#define RS485_DIR_RCU   RCU_GPIOA
#define RS485_DIR_PORT  GPIOA
#define RS485_DIR_PIN   GPIO_PIN_13

/* ========== TCP �ӿڣ����ֲ��䣩 ========== */
BOOL xMBTCPPortInit(USHORT usTCPPort) {
    (void)usTCPPort;
    current_client_pcb = NULL;
    tcp_recv_len = 0;
    return TRUE;
}

void vMBTCPPortDisable(void) {
    current_client_pcb = NULL;
}

BOOL xMBTCPPortGetRequest(UCHAR **ppucMBTCPFrame, USHORT *pusTCPLength) {
    if (tcp_recv_len == 0) return FALSE;
    *ppucMBTCPFrame = tcp_recv_buf;
    *pusTCPLength = tcp_recv_len;
    return TRUE;
}

BOOL xMBTCPPortSendResponse(const UCHAR *pucMBTCPFrame, USHORT usTCPLength) {
    if (current_client_pcb == NULL) return FALSE;
    err_t err = tcp_write(current_client_pcb, pucMBTCPFrame, usTCPLength, TCP_WRITE_FLAG_COPY);
    if (err != ERR_OK) return FALSE;
    tcp_output(current_client_pcb);
    return TRUE;
}

void mb_tcp_recv_input(struct tcp_pcb *pcb, uint8_t *data, uint16_t len) {
    if (len < 7) return;
    current_client_pcb = pcb;
    memcpy(tcp_recv_buf, data, len);
    tcp_recv_len = len;
    xMBPortEventPost(EV_FRAME_RECEIVED);
}

void mb_tcp_client_disconnect(void) {
    current_client_pcb = NULL;
    tcp_recv_len = 0;
}

/* ========== �¼����нӿ� ========== */
BOOL xMBPortEventInit(void) {
    g_mb_event = EV_READY;
    return TRUE;
}

BOOL xMBPortEventPost(eMBEventType eEvent) {
    g_mb_event = eEvent;
    return TRUE;
}

BOOL xMBPortEventGet(eMBEventType *eEvent) {
    if (g_mb_event == EV_READY) return FALSE;
    *eEvent = g_mb_event;
    g_mb_event = EV_READY;
    return TRUE;
}

/* ========== RS-485 ���ڽӿڣ�RTU ������չ�ã� ========== */
/* ���ڳ�ʼ�� */
bool xMBPortSerialInit(uint8_t ucPort, uint32_t ulBaudRate, uint8_t ucDataBits,
                       eMBParity eParity, uint8_t ucStopBits)
{
    (void)ucPort;  // ���ǽ�ʹ�� USART5

    /* ʹ��ʱ�� */
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_USART5);

    /* PA11: USART5_TX, PA12: USART5_RX */
    gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_11 | GPIO_PIN_12);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_11 | GPIO_PIN_12);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_11 | GPIO_PIN_12);

    /* PA13: RS-485 direction control
     * PA13 is SWDIO by default. On GD32F527 (Cortex-M33), configuring it
     * as GPIO output overrides the debug function. Note: SWD debugging
     * on this pin will be lost after this configuration.
     */
    gpio_mode_set(GPIOA, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, RS485_DIR_PIN);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, RS485_DIR_PIN);
    gpio_bit_reset(RS485_DIR_PORT, RS485_DIR_PIN);  /* Default: receive mode */

    /* USART �������ã�8 ����λ��1 ֹͣλ��żУ�顢115200 ������ */
    usart_deinit(USART5);
    usart_baudrate_set(USART5, ulBaudRate);
    usart_word_length_set(USART5, USART_WL_8BIT);
    usart_stop_bit_set(USART5, USART_STB_1BIT);
    usart_parity_config(USART5, USART_PM_EVEN);
    usart_hardware_flow_rts_config(USART5, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(USART5, USART_CTS_DISABLE);
    usart_receive_config(USART5, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART5, USART_TRANSMIT_ENABLE);

    /* ʹ�ܽ����жϣ������ж��ڷ���ʱ�ſ����� */
    nvic_irq_enable(USART5_IRQn, 0, 1);
    usart_interrupt_enable(USART5, USART_INT_RBNE);  // ���ջ������ǿ��ж�

    usart_enable(USART5);
    return true;
}

void xMBPortSerialClose(void) {
    usart_disable(USART5);
    nvic_irq_disable(USART5_IRQn);
}

bool xMBPortSerialPutByte(int8_t ucByte) {
    usart_data_transmit(USART5, (uint8_t)ucByte);
    while (RESET == usart_flag_get(USART5, USART_FLAG_TBE));
    return true;
}

bool xMBPortSerialGetByte(int8_t *pucByte) {
    if (RESET != usart_flag_get(USART5, USART_FLAG_RBNE)) {
        *pucByte = (int8_t)usart_data_receive(USART5);
        return true;
    }
    return false;
}

/* RS-485 �շ�ʹ�ܿ��� */
void vMBPortSerialEnable(BOOL xRxEnable, BOOL xTxEnable) {
    if (xTxEnable) {
        gpio_bit_set(RS485_DIR_PORT, RS485_DIR_PIN);    // ����״̬
        usart_interrupt_enable(USART5, USART_INT_TBE);  // �򿪷����ж�
    } else {
        usart_interrupt_disable(USART5, USART_INT_TBE); // �رշ����ж�
        gpio_bit_reset(RS485_DIR_PORT, RS485_DIR_PIN);  // ����״̬
    }
}

/* ========== RTU 50us ��ʱ���ӿڣ�TIMER2�� ========== */
static volatile uint32_t g_timer_50us_count = 0;

BOOL xMBPortTimersInit(uint16_t usTim1Timerout50us) {
    g_timer_50us_count = 0;
    (void)usTim1Timerout50us;

    /* ʹ�ܶ�ʱ��ʱ�� */
    rcu_periph_clock_enable(RCU_TIMER2);

    /* ��ʱ���������ã�50us ��� */
    timer_parameter_struct timer_initpara;
    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler = (SystemCoreClock / 20000) - 1;  // 20000Hz = 50us
    timer_initpara.alignedmode = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period = 65535;  // �����ڣ�ֻ���жϴ���
    timer_init(TIMER2, &timer_initpara);

    /* ʹ�ܸ����ж� */
    nvic_irq_enable(TIMER2_IRQn, 0, 1);
    timer_interrupt_enable(TIMER2, TIMER_INT_UP);
    timer_enable(TIMER2);
    return TRUE;
}

BOOL xMBPortTimerInit(uint16_t usTim1Timerout50us) {
    return xMBPortTimersInit(usTim1Timerout50us);
}

void vMBPortTimersDelay(uint16_t usTimeOutMS) {
    for (volatile uint32_t i = 0; i < usTimeOutMS * 8000; i++) {
        __NOP();
    }
}

void vMBPortTimersEnable(void) {
    /* ʹ�ܶ�ʱ�� */
    timer_enable(TIMER2);
}

void vMBPortTimersDisable(void) {
    timer_disable(TIMER2);
}

void xMBPortTimerClose(void) {
    timer_disable(TIMER2);
}

/* ========== USART5 / TIMER2 IRQ handlers ==========
 * MOVED to rtu_master.c to avoid duplicate symbol conflicts.
 * The RTU master owns USART5 for expansion-module communication.
 * FreeModbus TCP-only mode does not need these handlers.
 */

/* ========== assert support ========== */
void __aeabi_assert(const char *expr, const char *file, int line) {
    (void)expr;
    (void)file;
    (void)line;
    while (1) {
        __NOP();
    }
}
