./objects/err.o: ..\LwIP\api\err.c ..\LwIP\include\lwip\err.h \
  ..\LwIP\include\lwip\opt.h ..\User\arch\lwipopts.h \
  ..\LwIP\include\lwip\debug.h ..\LwIP\include\lwip\arch.h \
  ..\User\arch\cc.h ..\LwIP\include\lwip\def.h \
  ..\LwIP\include\lwip\sys.h ..\LwIP\include\lwip\errno.h
