./objects/inet_chksum.o: ..\LwIP\core\inet_chksum.c \
  ..\LwIP\include\lwip\opt.h ..\User\arch\lwipopts.h \
  ..\LwIP\include\lwip\debug.h ..\LwIP\include\lwip\arch.h \
  ..\User\arch\cc.h ..\LwIP\include\lwip\inet_chksum.h \
  ..\LwIP\include\lwip\pbuf.h ..\LwIP\include\lwip\err.h \
  ..\LwIP\include\lwip\ip_addr.h ..\LwIP\include\lwip\def.h \
  ..\LwIP\include\lwip\ip4_addr.h ..\LwIP\include\lwip\ip6_addr.h
