./objects/mem.o: ..\LwIP\core\mem.c ..\LwIP\include\lwip\opt.h \
  ..\User\arch\lwipopts.h ..\LwIP\include\lwip\debug.h \
  ..\LwIP\include\lwip\arch.h ..\User\arch\cc.h \
  ..\LwIP\include\lwip\mem.h ..\LwIP\include\lwip\def.h \
  ..\LwIP\include\lwip\sys.h ..\LwIP\include\lwip\stats.h \
  ..\LwIP\include\lwip\memp.h ..\LwIP\include\lwip\priv\memp_std.h \
  ..\LwIP\include\lwip\priv\memp_priv.h \
  ..\LwIP\include\lwip\priv\mem_priv.h ..\LwIP\include\lwip\err.h
