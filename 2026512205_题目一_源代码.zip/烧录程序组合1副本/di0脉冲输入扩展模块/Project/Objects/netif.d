./objects/netif.o: ..\LwIP\core\netif.c ..\LwIP\include\lwip\opt.h \
  ..\User\arch\lwipopts.h ..\LwIP\include\lwip\debug.h \
  ..\LwIP\include\lwip\arch.h ..\User\arch\cc.h \
  ..\LwIP\include\lwip\def.h ..\LwIP\include\lwip\ip_addr.h \
  ..\LwIP\include\lwip\ip4_addr.h ..\LwIP\include\lwip\ip6_addr.h \
  ..\LwIP\include\lwip\netif.h ..\LwIP\include\lwip\err.h \
  ..\LwIP\include\lwip\pbuf.h ..\LwIP\include\lwip\stats.h \
  ..\LwIP\include\lwip\mem.h ..\LwIP\include\lwip\memp.h \
  ..\LwIP\include\lwip\priv\memp_std.h \
  ..\LwIP\include\lwip\priv\memp_priv.h \
  ..\LwIP\include\lwip\priv\mem_priv.h \
  ..\LwIP\include\lwip\priv\tcp_priv.h ..\LwIP\include\lwip\tcp.h \
  ..\LwIP\include\lwip\tcpbase.h ..\LwIP\include\lwip\ip.h \
  ..\LwIP\include\lwip\ip4.h ..\LwIP\include\lwip\prot\ip4.h \
  ..\User\arch\bpstruct.h ..\User\arch\epstruct.h \
  ..\LwIP\include\lwip\ip6.h ..\LwIP\include\lwip\prot\ip.h \
  ..\LwIP\include\lwip\icmp.h ..\LwIP\include\lwip\prot\icmp.h \
  ..\LwIP\include\lwip\prot\tcp.h ..\LwIP\include\lwip\udp.h \
  ..\LwIP\include\lwip\priv\raw_priv.h ..\LwIP\include\lwip\snmp.h \
  ..\LwIP\include\lwip\igmp.h ..\LwIP\include\lwip\etharp.h \
  ..\LwIP\include\lwip\prot\ethernet.h ..\LwIP\include\lwip\prot\ieee.h \
  ..\LwIP\include\lwip\prot\etharp.h ..\LwIP\include\lwip\sys.h \
  ..\LwIP\include\netif\ethernet.h
