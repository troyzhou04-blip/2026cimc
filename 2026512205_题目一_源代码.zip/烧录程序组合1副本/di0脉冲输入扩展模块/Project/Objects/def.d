./objects/def.o: ..\LwIP\core\def.c ..\LwIP\include\lwip\opt.h \
  ..\User\arch\lwipopts.h ..\LwIP\include\lwip\debug.h \
  ..\LwIP\include\lwip\arch.h ..\User\arch\cc.h \
  ..\LwIP\include\lwip\def.h
