./objects/ethernetif.o: ethernetif.c ..\LwIP\include\lwip\opt.h \
  ..\User\arch\lwipopts.h ..\LwIP\include\lwip\debug.h \
  ..\LwIP\include\lwip\arch.h ..\User\arch\cc.h \
  ..\LwIP\include\lwip\def.h ..\LwIP\include\lwip\mem.h \
  ..\LwIP\include\lwip\pbuf.h ..\LwIP\include\lwip\err.h \
  ..\LwIP\include\lwip\stats.h ..\LwIP\include\lwip\memp.h \
  ..\LwIP\include\lwip\priv\memp_std.h \
  ..\LwIP\include\lwip\priv\memp_priv.h \
  ..\LwIP\include\lwip\priv\mem_priv.h ..\LwIP\include\lwip\sys.h \
  ..\LwIP\include\netif\etharp.h ..\LwIP\include\lwip\etharp.h \
  ..\LwIP\include\lwip\ip4_addr.h ..\LwIP\include\lwip\netif.h \
  ..\LwIP\include\lwip\ip_addr.h ..\LwIP\include\lwip\ip6_addr.h \
  ..\LwIP\include\lwip\ip4.h ..\LwIP\include\lwip\prot\ip4.h \
  ..\User\arch\bpstruct.h ..\User\arch\epstruct.h \
  ..\LwIP\include\lwip\prot\ethernet.h ..\LwIP\include\lwip\prot\ieee.h \
  ..\LwIP\include\lwip\prot\etharp.h ..\LwIP\include\netif\ethernet.h \
  ..\Firmware\CMSIS\GD\GD32F527\Include\gd32f527.h \
  M:\Keil5\ARM\PACK\ARM\CMSIS\6.2.0\CMSIS\Core\Include\core_cm33.h \
  ..\Firmware\CMSIS\GD\GD32F527\Include\system_gd32f527.h \
  ..\User\gd32f527_libopt.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_adc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_can.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_cau.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_crc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_ctc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_dac.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_dbg.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_dci.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_dma.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_enet.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_exmc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_exti.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_fmc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_fwdgt.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_gpio.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_hau.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_i2c.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_i2c_add.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_ipa.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_iref.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_misc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_pkcau.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_pmu.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_rcu.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_rtc.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_sai.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_sdio.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_spi.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_syscfg.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_timer.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_tli.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_trng.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_usart.h \
  ..\Firmware\GD32F527_standard_peripheral\Include\gd32f527_wwdgt.h \
  ..\User\systick.h
