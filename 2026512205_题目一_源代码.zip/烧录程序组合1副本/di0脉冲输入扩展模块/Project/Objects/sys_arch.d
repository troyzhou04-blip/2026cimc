./objects/sys_arch.o: ..\User\arch\sys_arch.c ..\User\arch\sys_arch.h
