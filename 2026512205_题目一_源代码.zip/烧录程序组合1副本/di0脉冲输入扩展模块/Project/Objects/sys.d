./objects/sys.o: ..\LwIP\core\sys.c ..\LwIP\include\lwip\opt.h \
  ..\User\arch\lwipopts.h ..\LwIP\include\lwip\debug.h \
  ..\LwIP\include\lwip\arch.h ..\User\arch\cc.h \
  ..\LwIP\include\lwip\sys.h
