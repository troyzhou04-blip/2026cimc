./objects/mbfuncdiag.o: ..\Firmware\CMSIS\GD\GD32F527\Source\mbfuncdiag.c
