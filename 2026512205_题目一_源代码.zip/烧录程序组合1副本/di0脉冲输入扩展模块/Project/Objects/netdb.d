./objects/netdb.o: ..\LwIP\api\netdb.c ..\LwIP\include\lwip\netdb.h \
  ..\LwIP\include\lwip\opt.h ..\User\arch\lwipopts.h \
  ..\LwIP\include\lwip\debug.h ..\LwIP\include\lwip\arch.h \
  ..\User\arch\cc.h
