./objects/ip4_addr.o: ..\LwIP\core\ipv4\ip4_addr.c \
  ..\LwIP\include\lwip\opt.h ..\User\arch\lwipopts.h \
  ..\LwIP\include\lwip\debug.h ..\LwIP\include\lwip\arch.h \
  ..\User\arch\cc.h ..\LwIP\include\lwip\ip_addr.h \
  ..\LwIP\include\lwip\def.h ..\LwIP\include\lwip\ip4_addr.h \
  ..\LwIP\include\lwip\ip6_addr.h ..\LwIP\include\lwip\netif.h \
  ..\LwIP\include\lwip\err.h ..\LwIP\include\lwip\pbuf.h \
  ..\LwIP\include\lwip\stats.h ..\LwIP\include\lwip\mem.h \
  ..\LwIP\include\lwip\memp.h ..\LwIP\include\lwip\priv\memp_std.h \
  ..\LwIP\include\lwip\priv\memp_priv.h \
  ..\LwIP\include\lwip\priv\mem_priv.h
