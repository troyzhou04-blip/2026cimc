./objects/altcp_alloc.o: ..\LwIP\core\altcp_alloc.c \
  ..\LwIP\include\lwip\opt.h ..\User\arch\lwipopts.h \
  ..\LwIP\include\lwip\debug.h ..\LwIP\include\lwip\arch.h \
  ..\User\arch\cc.h
