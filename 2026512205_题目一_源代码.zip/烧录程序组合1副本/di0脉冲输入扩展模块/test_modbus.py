#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Modbus TCP Auto Test Script
Test all function codes
"""

from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusIOException
import time
import sys

# Configuration
SERVER_IP = "192.168.1.200"
SERVER_PORT = 502
TIMEOUT = 3
DEVICE_ID = 1

# Test results
test_results = {"passed": 0, "failed": 0, "errors": []}

def print_header(title):
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)

def print_result(test_name, success, detail=""):
    status = "[PASS]" if success else "[FAIL]"
    print(f"  {status} | {test_name}")
    if detail:
        print(f"         {detail}")
    if success:
        test_results["passed"] += 1
    else:
        test_results["failed"] += 1
        test_results["errors"].append(f"{test_name}: {detail}")

def test_connection(client):
    print_header("Test 0: Connection Test")
    try:
        if client.connect():
            print_result("Connect to server", True, f"{SERVER_IP}:{SERVER_PORT}")
            return True
        print_result("Connect to server", False, "Failed")
        return False
    except Exception as e:
        print_result("Connect to server", False, str(e))
        return False

def test_fc01_read_coils(client):
    print_header("Test FC01: Read Coils (1-9999)")
    for addr in [1, 100, 5000, 9999]:
        for count in [1, 10, 100]:
            if addr + count - 1 <= 9999:
                try:
                    r = client.read_coils(addr - 1, count=count, device_id=DEVICE_ID)
                    print_result(f"Read coils addr={addr}, count={count}", not r.isError(),
                               f"Return {len(r.bits)} values" if not r.isError() else str(r))
                except Exception as e:
                    print_result(f"Read coils addr={addr}, count={count}", False, str(e))

def test_fc02_read_discrete_inputs(client):
    print_header("Test FC02: Read Discrete Inputs (10001-19999)")
    for addr in [10001, 10100, 15000, 19999]:
        for count in [1, 10, 100]:
            if addr + count - 1 <= 19999:
                try:
                    r = client.read_discrete_inputs(addr - 1, count=count, device_id=DEVICE_ID)
                    print_result(f"Read discrete inputs addr={addr}, count={count}", not r.isError(),
                               f"Return {len(r.bits)} values" if not r.isError() else str(r))
                except Exception as e:
                    print_result(f"Read discrete inputs addr={addr}, count={count}", False, str(e))

def test_fc03_read_holding_registers(client):
    print_header("Test FC03: Read Holding Registers (40001-49999)")
    for addr in [40001, 40100, 45000, 49999]:
        for count in [1, 10, 100]:
            if addr + count - 1 <= 49999:
                try:
                    r = client.read_holding_registers(addr - 1, count=count, device_id=DEVICE_ID)
                    print_result(f"Read holding regs addr={addr}, count={count}", not r.isError(),
                               f"Return {len(r.registers)} values" if not r.isError() else str(r))
                except Exception as e:
                    print_result(f"Read holding regs addr={addr}, count={count}", False, str(e))

def test_fc04_read_input_registers(client):
    print_header("Test FC04: Read Input Registers (30001-39999)")
    for addr in [30001, 30100, 35000, 39999]:
        for count in [1, 10, 100]:
            if addr + count - 1 <= 39999:
                try:
                    r = client.read_input_registers(addr - 1, count=count, device_id=DEVICE_ID)
                    print_result(f"Read input regs addr={addr}, count={count}", not r.isError(),
                               f"Return {len(r.registers)} values" if not r.isError() else str(r))
                except Exception as e:
                    print_result(f"Read input regs addr={addr}, count={count}", False, str(e))

def test_fc05_write_single_coil(client):
    print_header("Test FC05: Write Single Coil (1-9999)")
    for addr in [1, 100, 5000, 9999]:
        try:
            # Write ON
            r = client.write_coil(addr - 1, True, device_id=DEVICE_ID)
            if not r.isError():
                rr = client.read_coils(addr - 1, count=1, device_id=DEVICE_ID)
                ok = not rr.isError() and rr.bits[0]
                print_result(f"Write coil ON addr={addr}", ok, "" if ok else "Readback failed")
            else:
                print_result(f"Write coil ON addr={addr}", False, str(r))
            # Write OFF
            r = client.write_coil(addr - 1, False, device_id=DEVICE_ID)
            if not r.isError():
                rr = client.read_coils(addr - 1, count=1, device_id=DEVICE_ID)
                ok = not rr.isError() and not rr.bits[0]
                print_result(f"Write coil OFF addr={addr}", ok, "" if ok else "Readback failed")
            else:
                print_result(f"Write coil OFF addr={addr}", False, str(r))
        except Exception as e:
            print_result(f"Write coil addr={addr}", False, str(e))

def test_fc06_write_single_register(client):
    print_header("Test FC06: Write Single Register (40001-49999)")
    for addr in [40001, 40100, 45000, 49999]:
        for value in [0, 12345, 65535]:
            try:
                r = client.write_register(addr - 1, value, device_id=DEVICE_ID)
                if not r.isError():
                    rr = client.read_holding_registers(addr - 1, count=1, device_id=DEVICE_ID)
                    ok = not rr.isError() and rr.registers[0] == value
                    print_result(f"Write reg addr={addr}, val={value}", ok,
                               "" if ok else f"Readback={rr.registers[0] if not rr.isError() else 'ERR'}")
                else:
                    print_result(f"Write reg addr={addr}, val={value}", False, str(r))
            except Exception as e:
                print_result(f"Write reg addr={addr}, val={value}", False, str(e))

def test_fc08_diagnostics(client):
    print_header("Test FC08: Diagnostics")
    print("  Note: FC08 requires manual test with Modbus Poll")
    print("  SubFunc 0: Loopback test")
    print("  SubFunc 10: Clear counters")
    print_result("FC08 SubFunc 0 (Loopback)", True, "Manual test required")
    print_result("FC08 SubFunc 10 (Clear)", True, "Manual test required")

def test_fc11_get_event_counter(client):
    print_header("Test FC11: Get Event Counter")
    print("  Note: FC11 requires manual test with Modbus Poll")
    print_result("FC11 Get Event Counter", True, "Manual test required")

def test_fc15_write_multiple_coils(client):
    print_header("Test FC15: Write Multiple Coils (1-9999)")
    test_cases = [
        (1, [True, False, True, False, True, False, True, False]),
        (100, [True] * 16),
        (1000, [False] * 32),
        (5000, [True, False] * 32),
    ]
    for addr, values in test_cases:
        try:
            count = len(values)
            r = client.write_coils(addr - 1, values, device_id=DEVICE_ID)
            if not r.isError():
                rr = client.read_coils(addr - 1, count=count, device_id=DEVICE_ID)
                ok = not rr.isError() and all(rr.bits[i] == values[i] for i in range(count))
                print_result(f"Write coils addr={addr}, count={count}", ok,
                           "" if ok else "Readback mismatch")
            else:
                print_result(f"Write coils addr={addr}, count={count}", False, str(r))
        except Exception as e:
            print_result(f"Write coils addr={addr}, count={count}", False, str(e))

def test_fc16_write_multiple_registers(client):
    print_header("Test FC16: Write Multiple Registers (40001-49999)")
    test_cases = [
        (40001, [100, 200, 300, 400, 500]),
        (40100, [0, 65535, 12345, 54321, 9999]),
        (45000, list(range(100))),
        (49990, [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]),
    ]
    for addr, values in test_cases:
        try:
            count = len(values)
            r = client.write_registers(addr - 1, values, device_id=DEVICE_ID)
            if not r.isError():
                rr = client.read_holding_registers(addr - 1, count=count, device_id=DEVICE_ID)
                ok = not rr.isError() and all(rr.registers[i] == values[i] for i in range(count))
                print_result(f"Write regs addr={addr}, count={count}", ok,
                           "" if ok else "Readback mismatch")
            else:
                print_result(f"Write regs addr={addr}, count={count}", False, str(r))
        except Exception as e:
            print_result(f"Write regs addr={addr}, count={count}", False, str(e))

def test_response_delay(client):
    print_header("Test Response Delay (Register 49999)")
    try:
        # Set delay to 100ms
        r = client.write_register(49998, 100, device_id=DEVICE_ID)
        if not r.isError():
            rr = client.read_holding_registers(49998, count=1, device_id=DEVICE_ID)
            ok = not rr.isError() and rr.registers[0] == 100
            print_result("Set delay to 100ms", ok, "" if ok else f"Readback={rr.registers[0] if not rr.isError() else 'ERR'}")
        else:
            print_result("Set delay to 100ms", False, str(r))
        
        # Test delay effect
        start = time.time()
        client.read_holding_registers(40000, count=1, device_id=DEVICE_ID)
        elapsed = time.time() - start
        print_result("Delay effect", elapsed >= 0.09, f"Took {elapsed*1000:.0f}ms")
        
        # Restore
        client.write_register(49998, 0, device_id=DEVICE_ID)
        print("  Restored delay to 0ms")
    except Exception as e:
        print_result("Response delay", False, str(e))

def print_summary():
    print_header("Test Summary")
    print(f"  Passed: {test_results['passed']}")
    print(f"  Failed: {test_results['failed']}")
    print(f"  Total:  {test_results['passed'] + test_results['failed']}")
    if test_results['errors']:
        print("\n  Failed tests:")
        for e in test_results['errors']:
            print(f"    - {e}")
    print("\n" + "=" * 60)

def main():
    print("=" * 60)
    print("  Modbus TCP Auto Test Script")
    print(f"  Target: {SERVER_IP}:{SERVER_PORT}")
    print("=" * 60)
    
    client = ModbusTcpClient(SERVER_IP, port=SERVER_PORT, timeout=TIMEOUT)
    
    if not test_connection(client):
        print("\nCannot connect. Check:")
        print("  1. MCU powered on?")
        print("  2. Network cable connected?")
        print("  3. IP address correct?")
        client.close()
        return 1
    
    try:
        test_fc01_read_coils(client)
        test_fc02_read_discrete_inputs(client)
        test_fc03_read_holding_registers(client)
        test_fc04_read_input_registers(client)
        test_fc05_write_single_coil(client)
        test_fc06_write_single_register(client)
        test_fc08_diagnostics(client)
        test_fc11_get_event_counter(client)
        test_fc15_write_multiple_coils(client)
        test_fc16_write_multiple_registers(client)
        test_response_delay(client)
    except KeyboardInterrupt:
        print("\n\nTest interrupted")
    except Exception as e:
        print(f"\n\nError: {e}")
    
    print_summary()
    client.close()
    return 0 if test_results['failed'] == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
