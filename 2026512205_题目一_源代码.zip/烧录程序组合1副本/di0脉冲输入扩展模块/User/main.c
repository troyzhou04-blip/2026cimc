#include "gd32f527.h"
#include "usart_debug.h"
#include "rtuslave.h"
#include <string.h>
#include <stdio.h>
#include "mb.h"
#include "pwmtimer_config.h"

volatile uint32_t g_tick = 0;
static uint32_t last_print_tick = 0;

static void systick_init(void)
{
    SysTick_Config(SystemCoreClock / 1000);
}

/* ==================== Main ==================== */
int main(void)
{
    SystemInit();
    systick_init();

    usart_debug_init(115200);
	printf("SystemCoreClock=%lu\r\n", SystemCoreClock);
	
    printf("\r\n=== Modbus RTU DI Slave (Digital Input Module) Starting ===\r\n");
    printf("=== Slave Addr=%d, Baud=%d ===\r\n", RTU_SLAVE_ADDR, RTU_SLAVE_BAUDRATE);

    /* 初始化RTU从站(DI模块) */
    rtu_slave_init();

    printf("=== Ready - 8ch DI, 4ch Pulse Count ===\r\n");
    printf("=== Waiting for master commands... ===\r\n\r\n");

    while(1)
    {
        /* Modbus RTU从站轮询 */
        rtu_slave_poll();
        
        /* 每5秒打印一次状态 */
        if (g_tick - last_print_tick >= 5000) {
            last_print_tick = g_tick;
            rtu_slave_print_status();
        }
    }
}
