#include "pwmtimer_config.h"
#include <stdio.h>
#include "gd32f527.h"

/* ========== 脉冲溢出计数 (在中断中递增) ========== */
static volatile uint32_t pulse_overflow[DI_PULSE_CHANNELS] = {0};

/* 定时器外设映射 */
static const uint32_t pulse_timer[DI_PULSE_CHANNELS] = {TIMER1, TIMER3, TIMER13, TIMER2};

/* ========== 8路DI引脚初始化 ========== */
void di_pins_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);

    /* CH0~CH3: 复用功能输入(定时器通道), 下拉 */
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLDOWN, GPIO_PIN_0);
    gpio_af_set(GPIOA, GPIO_AF_1, GPIO_PIN_0);       /* PA0  -> TIM1_CH0 */

    gpio_mode_set(GPIOB, GPIO_MODE_AF, GPIO_PUPD_PULLDOWN, GPIO_PIN_6);
    gpio_af_set(GPIOB, GPIO_AF_2, GPIO_PIN_6);       /* PB6  -> TIM3_CH0 */

    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLDOWN, GPIO_PIN_7);
    gpio_af_set(GPIOA, GPIO_AF_9, GPIO_PIN_7);       /* PA7  -> TIM13_CH0 */

    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLDOWN, GPIO_PIN_6);
    gpio_af_set(GPIOA, GPIO_AF_2, GPIO_PIN_6);       /* PA6  -> TIM2_CH0 */

    /* CH4~CH7: 普通GPIO输入, 上拉 */
    gpio_mode_set(GPIOC, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_6);  /* PC6 */
    gpio_mode_set(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_9);  /* PB9 */
    gpio_mode_set(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_7);  /* PB7 */
    gpio_mode_set(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_8);  /* PB8 */
}

/* ========== 单个定时器配置为外部时钟模式0 (脉冲计数) ========== */
/*
 * 工作原理:
 *   CH0引脚输入信号 → 输入滤波 → TI0FE0作为触发源 → 外部时钟模式0
 *   每个上升沿, 定时器计数器自动+1, CPU零开销
 *   计数器溢出(65535→0)时产生更新中断, 软件维护32位扩展计数
 *
 * 脉冲计数精度: 纯硬件计数, 误差为0%, 满足赛题≤0.1%要求
 */
static void pulse_timer_single_init(uint32_t timer_periph, uint32_t irqn)
{
    timer_parameter_struct tpara;
    timer_ic_parameter_struct icpara;

    /* 使能定时器时钟 */
    switch (timer_periph) {
        case TIMER1:  rcu_periph_clock_enable(RCU_TIMER1);  break;
        case TIMER3:  rcu_periph_clock_enable(RCU_TIMER3);  break;
        case TIMER13: rcu_periph_clock_enable(RCU_TIMER13); break;
        case TIMER2:  rcu_periph_clock_enable(RCU_TIMER2);  break;
    }

    timer_deinit(timer_periph);

    /* 基本参数: 不分频, 向上计数, 周期=65535 */
    timer_struct_para_init(&tpara);
    tpara.prescaler         = 0;
    tpara.alignedmode       = TIMER_COUNTER_EDGE;
    tpara.counterdirection  = TIMER_COUNTER_UP;
    tpara.period            = 0xFFFF;
    tpara.clockdivision     = TIMER_CKDIV_DIV1;
    tpara.repetitioncounter = 0;
    timer_init(timer_periph, &tpara);

    /* CH0配置为输入捕获: 直接映射, 上升沿, 无预分频, 滤波=4 */
    timer_channel_input_struct_para_init(&icpara);
    icpara.icpolarity   = TIMER_IC_POLARITY_RISING;
    icpara.icselection  = TIMER_IC_SELECTION_DIRECTTI;
    icpara.icprescaler  = TIMER_IC_PSC_DIV1;
    icpara.icfilter     = 4;
    timer_input_capture_config(timer_periph, TIMER_CH_0, &icpara);

    /* 从模式: 外部时钟模式0, 触发源=TI0FE0(滤波后的CH0输入) */
    timer_slave_mode_select(timer_periph, TIMER_SLAVE_MODE_EXTERNAL0);
    timer_input_trigger_source_select(timer_periph, TIMER_SMCFG_TRGSEL_CI0FE0);

    /* 使能更新中断(溢出时触发) */
    timer_interrupt_flag_clear(timer_periph, TIMER_INT_FLAG_UP);
    nvic_irq_enable(irqn, 1, 0);
    timer_interrupt_enable(timer_periph, TIMER_INT_UP);

    /* 计数器清零并启动 */
    timer_counter_value_config(timer_periph, 0);
    timer_enable(timer_periph);
}

/* ========== 4路脉冲计数定时器初始化 ========== */
void di_pulse_capture_init(void)
{
    rcu_timer_clock_prescaler_config(RCU_TIMER_PSC_MUL4);

    pulse_timer_single_init(TIMER1,  TIMER1_IRQn);                   /* CH0: PA0 */
    pulse_timer_single_init(TIMER3,  TIMER3_IRQn);                   /* CH1: PB6 */
    pulse_timer_single_init(TIMER13, TIMER7_TRG_CMT_TIMER13_IRQn);   /* CH2: PA7 */
    pulse_timer_single_init(TIMER2,  TIMER2_IRQn);                   /* CH3: PA6 */
}

/* ========== 读取32位脉冲计数 (带溢出保护) ========== */
uint32_t di_pulse_count_read(uint8_t ch)
{
    if (ch >= DI_PULSE_CHANNELS) return 0;

    uint32_t ovf1, ovf2, cnt;
    do {
        ovf1 = pulse_overflow[ch];
        cnt  = timer_counter_read(pulse_timer[ch]);
        ovf2 = pulse_overflow[ch];
    } while (ovf1 != ovf2);    /* 防止读取过程中发生溢出 */
    return (ovf1 << 16) | cnt;
}

/* ========== 重置脉冲计数器 ========== */
void di_pulse_count_reset(uint8_t ch)
{
    if (ch >= DI_PULSE_CHANNELS) return;
    __disable_irq();
    pulse_overflow[ch] = 0;
    timer_counter_value_config(pulse_timer[ch], 0);
    __enable_irq();
}

/* ========== 扫描4路GPIO输入 (CH4~CH7) ========== */
void di_scan(uint16_t *di_data)
{
    if (gpio_input_bit_get(GPIOC, GPIO_PIN_6))  *di_data |=  (1 << 4);
    else                                         *di_data &= ~(1 << 4);

    if (gpio_input_bit_get(GPIOB, GPIO_PIN_9))  *di_data |=  (1 << 5);
    else                                         *di_data &= ~(1 << 5);

    if (gpio_input_bit_get(GPIOB, GPIO_PIN_7))  *di_data |=  (1 << 6);
    else                                         *di_data &= ~(1 << 6);

    if (gpio_input_bit_get(GPIOB, GPIO_PIN_8))  *di_data |=  (1 << 7);
    else                                         *di_data &= ~(1 << 7);
}

/* ========== 脉冲计数溢出中断处理 ========== */

void TIMER1_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP) != RESET) {
        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
        pulse_overflow[0]++;
    }
}

void TIMER3_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER3, TIMER_INT_FLAG_UP) != RESET) {
        timer_interrupt_flag_clear(TIMER3, TIMER_INT_FLAG_UP);
        pulse_overflow[1]++;
    }
}

void TIMER7_TRG_CMT_TIMER13_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER13, TIMER_INT_FLAG_UP) != RESET) {
        timer_interrupt_flag_clear(TIMER13, TIMER_INT_FLAG_UP);
        pulse_overflow[2]++;
    }
}

void TIMER2_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER2, TIMER_INT_FLAG_UP) != RESET) {
        timer_interrupt_flag_clear(TIMER2, TIMER_INT_FLAG_UP);
        pulse_overflow[3]++;
    }
}
