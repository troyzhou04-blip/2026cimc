#include "usart_debug.h"
#include <stdio.h>

/*!
    \brief      初始化USART5作为调试串口 (PA11=TX, PA12=RX)
    \param[in]  baudrate: 波特率，例如 115200
*/
void usart_debug_init(uint32_t baudrate)
{
    /* 1. 使能时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_USART5);

    /* 2. 配置 PA11 (TX) 为复用推挽输出 */
    gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_11);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_11);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_11);

    /* 3. 配置 PA12 (RX) 为复用浮空输入 */
    gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_12);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_12);

    /* 4. USART 基本配置 */
    usart_deinit(USART5);
    usart_baudrate_set(USART5, baudrate);
    usart_word_length_set(USART5, USART_WL_8BIT);
    usart_stop_bit_set(USART5, USART_STB_1BIT);
    usart_parity_config(USART5, USART_PM_NONE);
    usart_hardware_flow_rts_config(USART5, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(USART5, USART_CTS_DISABLE);
    usart_receive_config(USART5, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART5, USART_TRANSMIT_ENABLE);

    usart_enable(USART5);
}

/* 发送单字节（用于重定向 printf） */
void usart_debug_send_byte(uint8_t byte)
{
    while(RESET == usart_flag_get(USART5, USART_FLAG_TBE));
    usart_data_transmit(USART5, byte);
}

/* 发送字符串（方便直接使用） */
void usart_debug_send_string(char *str)
{
    while(*str) {
        usart_debug_send_byte(*str++);
    }
}

/* 重定向 printf 到串口，将此函数放入任意.c文件中即可 */
int _write(int file, char *ptr, int len)
{
    for(int i = 0; i < len; i++) {
        usart_debug_send_byte(ptr[i]);
    }
    return len;
}
