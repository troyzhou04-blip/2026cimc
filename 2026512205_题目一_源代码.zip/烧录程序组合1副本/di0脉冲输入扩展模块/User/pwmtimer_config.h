#ifndef PWMTIMER_CONFIG_H
#define PWMTIMER_CONFIG_H

#include "gd32f527.h"
#include <stdint.h>

/* ========== DI模块硬件配置 ========== */

/*
 * 8路数字量输入引脚分配 (与DO模块引脚相同):
 *   CH0: PA0  TIM1_CH0   脉冲计数 (定时器外部时钟模式)
 *   CH1: PB6  TIM3_CH0   脉冲计数
 *   CH2: PA7  TIM13_CH0  脉冲计数
 *   CH3: PA6  TIM2_CH0   脉冲计数
 *   CH4: PC6  GPIO输入
 *   CH5: PB9  GPIO输入
 *   CH6: PB7  GPIO输入
 *   CH7: PB8  GPIO输入
 */

#define DI_PULSE_CHANNELS   4       /* 脉冲计数通道数 */

/* 初始化函数 */
void di_pins_init(void);            /* 8路DI引脚初始化 (4路AF输入 + 4路GPIO输入) */
void di_pulse_capture_init(void);   /* 4路定时器脉冲计数初始化 (TIM1/TIM3/TIM13/TIM2) */

/* 数据读取函数 */
uint32_t di_pulse_count_read(uint8_t ch);       /* 读取32位脉冲计数 (ch=0~3) */
void     di_pulse_count_reset(uint8_t ch);      /* 重置脉冲计数器 */
void     di_scan(uint16_t *di_data);            /* 扫描4路GPIO输入, 更新di_data bit4~7 */

#endif /* PWMTIMER_CONFIG_H */
