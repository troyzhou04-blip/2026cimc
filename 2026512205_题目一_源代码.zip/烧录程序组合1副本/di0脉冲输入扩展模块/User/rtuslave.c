#include "rtuslave.h"
#include "pwmtimer_config.h"
#include "mb.h"
#include "mbport.h"
#include <string.h>
#include <stdio.h>

/* External debug functions */
extern uint32_t portrtu_get_isr_rx_count(void);
extern volatile uint32_t tmr_irq_count;
extern volatile uint32_t dbg_send_enter;
extern volatile uint32_t dbg_tbe_irq;
extern volatile uint32_t dbg_put_byte;
extern uint32_t portrtu_get_tbe_flag(void);
extern uint32_t portrtu_get_tc_flag(void);

volatile uint32_t comm_count = 0;

static uint8_t  last_fc = 0;
static uint16_t last_addr = 0;
static uint16_t last_count = 0;
static uint32_t last_tick = 0;

extern volatile uint32_t g_tick;

/* 8路DI状态 bit0~7 (bit0~3由脉冲计数器存在, bit4~7由GPIO扫描) */
static uint16_t di_data = 0;

/* ========== FreeModbus回调函数 ========== */

/* FC02: 读离散输入 - 8路DI状态 */
eMBErrorCode eMBRegDiscreteCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNDiscrete)
{
    USHORT usAddr = usAddress - 1;

    if (usAddr + usNDiscrete > DI_CHANNEL_COUNT) return MB_ENOREG;

    comm_count++;
    last_fc = 0x02;
    last_addr = usAddr;
    last_count = usNDiscrete;
    last_tick = g_tick;

    /* 实时扫描GPIO输入 (CH4~CH7) */
    di_scan(&di_data);

    /* 打包bit返回 */
    USHORT usByteCount = (usNDiscrete + 7) / 8;
    for (USHORT i = 0; i < usByteCount; i++) {
        UCHAR ucBits = 0;
        for (USHORT j = 0; j < 8; j++) {
            USHORT usBitIdx = i * 8 + j;
            if (usBitIdx < usNDiscrete) {
                if (di_data & (1 << (usAddr + usBitIdx))) {
                    ucBits |= (1 << j);
                }
            }
        }
        pucRegBuffer[i] = ucBits;
    }
    // printf("[DI_FC02] READ addr=%d, qty=%d, data=0x%02X\r\n", usAddr, usNDiscrete, di_data & 0xFF);
    return MB_ENOERR;
}

/* FC01/05/15: 读写线圈 - DI模块无线圈 */
eMBErrorCode eMBRegCoilsCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNCoils, eMBRegisterMode eMode)
{
    (void)pucRegBuffer; (void)usAddress; (void)usNCoils; (void)eMode;
    return MB_ENOREG;
}

/* FC03/06/16: 读写保持寄存器 - 用于脉冲清零 (FC06)
 * 地址0-3: 对应通道0-3的脉冲计数清零
 * 写入值1=清零, 其他值无效
 */
eMBErrorCode eMBRegHoldingCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs, eMBRegisterMode eMode)
{
    USHORT usAddr = usAddress - 1;

    if (usAddr + usNRegs > DI_PULSE_CHANNELS) return MB_ENOREG;

    if (eMode == MB_REG_WRITE) {
        /* FC06写单个寄存器 / FC16写多个寄存器 */
        for (USHORT i = 0; i < usNRegs; i++) {
            uint16_t value = ((uint16_t)pucRegBuffer[i * 2] << 8) | pucRegBuffer[i * 2 + 1];
            if (value == 1) {
                di_pulse_count_reset(usAddr + i);
            }
        }
        return MB_ENOERR;
    } else {
        /* FC03读: 暂不支持读取 */
        return MB_ENOREG;
    }
}

/* FC04: 读输入寄存器 - 4路脉冲计数 (Dint, 每路2个寄存器) */
/* 寄存器布局:
 * 地址 0-1:  CH0脉冲计数 (高16位+低16位)
 * 地址 2-3:  CH1脉冲计数
 * 地址 4-5:  CH2脉冲计数
 * 地址 6-7:  CH3脉冲计数
 */
eMBErrorCode eMBRegInputCB(UCHAR *pucRegBuffer, USHORT usAddress, USHORT usNRegs)
{
    USHORT usAddr = usAddress - 1;

    if (usAddr + usNRegs > INPUT_REG_COUNT) return MB_ENOREG;

    comm_count++;
    last_fc = 0x04;
    last_addr = usAddr;
    last_count = usNRegs;
    last_tick = g_tick;

    for (USHORT i = 0; i < usNRegs; i++) {
        USHORT regIdx = usAddr + i;
        uint8_t ch   = regIdx / 2;     /* 通道号 */
        uint8_t half = regIdx % 2;     /* 0=高16位, 1=低16位 */
        uint32_t cnt = di_pulse_count_read(ch);
        uint32_t value = (half == 0) ? (cnt >> 16) : (cnt & 0xFFFF);

        pucRegBuffer[i * 2]     = (uint8_t)(value >> 8);
        pucRegBuffer[i * 2 + 1] = (uint8_t)(value & 0xFF);
    }
    // printf("[DI_FC04] READ addr=%d, qty=%d\r\n", usAddr, usNRegs);
    // printf("[DI_FC04] PULSE: CH0=%lu CH1=%lu CH2=%lu CH3=%lu\r\n",
    //        di_pulse_count_read(0), di_pulse_count_read(1),
    //        di_pulse_count_read(2), di_pulse_count_read(3));
    return MB_ENOERR;
}

/* ========== 公共接口函数 ========== */

void rtu_slave_init(void)
{
    /* 硬件初始化 (pwmtimer_config.c) */
    di_pins_init();             /* 8路DI引脚 */
    di_pulse_capture_init();    /* 4路定时器脉冲计数 */

    /* Modbus RTU从站初始化 */
    eMBErrorCode eStatus = eMBInit(MB_RTU, RTU_SLAVE_ADDR, 1, RTU_SLAVE_BAUDRATE, MB_PAR_NONE, 1);
    if (eStatus != MB_ENOERR) return;

    eStatus = eMBEnable();
    if (eStatus != MB_ENOERR) return;
}

void rtu_slave_poll(void)
{
    eMBPoll();
}

uint8_t rtu_slave_get_di(uint8_t channel)
{
    if (channel >= DI_CHANNEL_COUNT) return 0;
    di_scan(&di_data);
    return (di_data >> channel) & 1;
}

uint16_t rtu_slave_get_di_all(void)
{
    di_scan(&di_data);
    return di_data & 0xFF;
}

uint32_t rtu_slave_get_pulse_count(uint8_t channel)
{
    return di_pulse_count_read(channel);
}

void rtu_slave_reset_pulse_count(uint8_t channel)
{
    di_pulse_count_reset(channel);
}

void rtu_slave_print_status(void)
{
    // di_scan(&di_data);
    // uint32_t isr_rx = portrtu_get_isr_rx_count();
    // (void)isr_rx;
    // printf("[DI] State=0x%02X Comm=%lu ISR_RX=%lu\r\n", di_data & 0xFF, comm_count, isr_rx);
    // printf("[PULSE] CH0=%lu CH1=%lu CH2=%lu CH3=%lu\r\n",
    //        di_pulse_count_read(0), di_pulse_count_read(1),
    //        di_pulse_count_read(2), di_pulse_count_read(3));
    // printf("[LAST] FC=0x%02X Addr=%d Qty=%d Tick=%lu\r\n",
    //        last_fc, last_addr, last_count, last_tick);
}
