/* portrtu.c - FreeModbus RTU Slave Porting for GD32F527
 * USART0 (PA9/TX→MAX485_DI, PA10/RX→MAX485_RO) + PB1 RS-485 Direction
 * TIMER6 for T3.5 timeout (TIMER2 reserved for TIM2 pulse output PA6)
 */
#include <string.h>
#include "mbport.h"
#include "gd32f527.h"
#include "gd32f527_timer.h"
#include "usart_debug.h"
#include <stdio.h>
#include "rtuslave.h"
/* ========== RS-485 Direction Control ========== */
#define RS485_DIR_PORT  GPIOB
#define RS485_DIR_PIN   GPIO_PIN_1

/* ========== Global Variables ========== */
static volatile eMBEventType g_mb_event = EV_READY;
static volatile uint32_t isr_rx_count = 0;  /* Debug: count received bytes in ISR */

volatile uint32_t tmr_irq_count = 0;
extern volatile uint32_t comm_count;

/* 发送链路调试计数器 */
volatile uint32_t dbg_send_enter = 0;    /* vMBPortSerialEnable(TX) 被调用次数 */
volatile uint32_t dbg_tbe_irq = 0;       /* TBE 中断触发次数 */
volatile uint32_t dbg_put_byte = 0;      /* xMBPortSerialPutByte 被调用次数 */
volatile uint32_t dbg_txe_count = 0;     /* USART TXE 标志状态 */

uint32_t portrtu_get_tbe_flag(void) {
    return usart_flag_get(USART0, USART_FLAG_TBE) ? 1 : 0;
}

uint32_t portrtu_get_tc_flag(void) {
    return usart_flag_get(USART0, USART_FLAG_TC) ? 1 : 0;
}

static volatile uint8_t dbg_rx_buf[256];
static volatile uint8_t dbg_rx_idx = 0;

/* Ring buffer for received bytes */
#define RX_RING_SIZE 256
static volatile uint8_t rx_ring_buf[RX_RING_SIZE];
static volatile uint16_t rx_ring_head = 0;  // write index (ISR)
static volatile uint16_t rx_ring_tail = 0;  // read index (main)


/* ========== Event Interface ========== */
BOOL xMBPortEventInit(void) {
    g_mb_event = EV_READY;
    return TRUE;
}

BOOL xMBPortEventPost(eMBEventType eEvent) {
    g_mb_event = eEvent;
    return TRUE;
}

BOOL xMBPortEventGet(eMBEventType *eEvent) {
    if (g_mb_event == EV_READY) return FALSE;
    *eEvent = g_mb_event;
    g_mb_event = EV_READY;
    return TRUE;
}

/* ========== Serial Port Interface (USART0) ========== */
BOOL xMBPortSerialInit(UCHAR ucPort, ULONG ulBaudRate, UCHAR ucDataBits,
                       eMBParity eParity, UCHAR ucStopBits) {
    (void)ucPort;
    (void)ucDataBits;

    /* Enable clocks */
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_USART0);

    /* PA9: USART0_TX, PA10: USART0_RX */
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_9 | GPIO_PIN_10);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_9 | GPIO_PIN_10);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9 | GPIO_PIN_10);

    /* PB1: RS-485 direction control (output) */
    gpio_mode_set(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, RS485_DIR_PIN);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, RS485_DIR_PIN);
    gpio_bit_reset(RS485_DIR_PORT, RS485_DIR_PIN);  /* Default: receive mode */

    /* USART configuration */
    usart_deinit(USART0);
    usart_baudrate_set(USART0, ulBaudRate);
    usart_word_length_set(USART0, USART_WL_8BIT);
    usart_stop_bit_set(USART0, ucStopBits == 2 ? USART_STB_2BIT : USART_STB_1BIT);

    /* Parity */
    switch (eParity) {
        case MB_PAR_ODD:
            usart_parity_config(USART0, USART_PM_ODD);
            break;
        case MB_PAR_EVEN:
            usart_parity_config(USART0, USART_PM_EVEN);
            break;
        default:
            usart_parity_config(USART0, USART_PM_NONE);
            break;
    }

    usart_hardware_flow_rts_config(USART0, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(USART0, USART_CTS_DISABLE);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);

    /* Enable RX interrupt (TX interrupts will be enabled when needed) */
    nvic_irq_enable(USART0_IRQn, 1, 0);
    usart_interrupt_enable(USART0, USART_INT_RBNE);

    /* Clear ring buffer */
    rx_ring_head = 0;
    rx_ring_tail = 0;

    usart_enable(USART0);
    return TRUE;
}

void xMBPortSerialClose(void) {
    usart_disable(USART0);
    nvic_irq_disable(USART0_IRQn);
}

BOOL xMBPortSerialPutByte(CHAR ucByte) {
    dbg_put_byte++;
    /* 非阻塞写入数据寄存器。
     * 调用上下文：xMBRTUTransmitFSM → TBE 中断。
     * TBE 已置位（中断触发条件），直接写入即可。
     * RS-485 方向已由 vMBPortSerialEnable(FALSE, TRUE) 设为发送。 */
    usart_data_transmit(USART0, (uint8_t)ucByte);
    return TRUE;
}

BOOL xMBPortSerialGetByte(CHAR *pucByte) {
    if (rx_ring_tail != rx_ring_head) {
        *pucByte = (CHAR)rx_ring_buf[rx_ring_tail];
        rx_ring_tail = (rx_ring_tail + 1) % RX_RING_SIZE;
        
        // 记录到调试缓冲区
        if (dbg_rx_idx < sizeof(dbg_rx_buf)) {
            dbg_rx_buf[dbg_rx_idx++] = (uint8_t)*pucByte;
        } else {
            dbg_rx_idx = 0;
            dbg_rx_buf[dbg_rx_idx++] = (uint8_t)*pucByte;
        }
        return TRUE;
    }
    return FALSE;
}


/* RS-485 direction control */
void vMBPortSerialEnable(BOOL xRxEnable, BOOL xTxEnable) {
    if (xTxEnable) {
        dbg_send_enter++;
        /* 切换到发送模式 */
        gpio_bit_set(RS485_DIR_PORT, RS485_DIR_PIN);
        /* 禁用接收中断，启用发送中断 */
        usart_interrupt_disable(USART0, USART_INT_RBNE);
        usart_interrupt_enable(USART0, USART_INT_TBE);
    } else {
        /* 禁用发送中断 */
        usart_interrupt_disable(USART0, USART_INT_TBE);
        /* 等待最后一个字节完全发送完毕（移位寄存器空） */
        while (!usart_flag_get(USART0, USART_FLAG_TC));
        /* 切换到接收模式 */
        gpio_bit_reset(RS485_DIR_PORT, RS485_DIR_PIN);
    }

    if (xRxEnable) {
        /* 清空环形缓冲区 */
        rx_ring_head = 0;
        rx_ring_tail = 0;
        /* 启用接收中断 */
        usart_interrupt_enable(USART0, USART_INT_RBNE);
    }
}

/* ========== Timer Interface (TIMER6 for T3.5) ========== */

BOOL xMBPortTimersInit(USHORT usTimeOut50us) {
    rcu_periph_clock_enable(RCU_TIMER6);

    timer_parameter_struct timer_initpara;
    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler = (SystemCoreClock / 20000) - 1;  /* 50us tick */
    timer_initpara.alignedmode = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period = usTimeOut50us;
    timer_init(TIMER6, &timer_initpara);

    nvic_irq_enable(TIMER6_IRQn, 0, 0);
    timer_interrupt_enable(TIMER6, TIMER_INT_UP);
    
    return TRUE;
}

void vMBPortTimersEnable(void) {
    timer_counter_value_config(TIMER6, 0);
    timer_enable(TIMER6);
}

void vMBPortTimersDisable(void) {
    timer_disable(TIMER6);
}

void vMBPortTimersDelay(USHORT usTimeOutMS) {
    /* Simple delay implementation */
    for (volatile uint32_t i = 0; i < usTimeOutMS * 8000; i++) {
        __NOP();
    }
}

/* ========== Interrupt Handlers ========== */
void USART0_IRQHandler(void) {
    /* Character received */
    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_RBNE) != RESET) {
        uint8_t ch = usart_data_receive(USART0);
        isr_rx_count++;

        /* Store in ring buffer */
        rx_ring_buf[rx_ring_head] = ch;
        rx_ring_head = (rx_ring_head + 1) % RX_RING_SIZE;

        pxMBFrameCBByteReceived();
    }

    /* Transmit buffer empty - send next byte */
    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_TBE) != RESET) {
        dbg_tbe_irq++;
        pxMBFrameCBTransmitterEmpty();
    }
}

/* Get ISR rx count for debugging */
uint32_t portrtu_get_isr_rx_count(void) {
    return isr_rx_count;
}

void TIMER6_IRQHandler(void) {
    if (timer_interrupt_flag_get(TIMER6, TIMER_INT_FLAG_UP) != RESET) {
        timer_interrupt_flag_clear(TIMER6, TIMER_INT_FLAG_UP);
        timer_disable(TIMER6);
        tmr_irq_count++;
        pxMBPortCBTimerExpired();
    }
}

/* ========== Assert Support ========== */
void __aeabi_assert(const char *expr, const char *file, int line) {
    (void)expr;
    (void)file;
    (void)line;
    while (1) {
        __NOP();
    }
}

/* 获取调试缓冲区指针和有效字节数 */
void portrtu_get_dbg_rx(uint8_t **buf, volatile uint8_t *idx) {
    *buf = (uint8_t *)dbg_rx_buf;
    *idx = dbg_rx_idx;
}
