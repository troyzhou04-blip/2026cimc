#ifndef _RTU_SLAVE_H
#define _RTU_SLAVE_H

#include "gd32f527.h"
#include <stdint.h>
#include <stdbool.h>

/* 从站配置 */
#define RTU_SLAVE_ADDR          1       /* Modbus RTU 从站地址 (DI模块，对应主站addr=1) */
#define RTU_SLAVE_BAUDRATE      115200  /* 波特率 */
#define RTU_SLAVE_PARITY        0       /* 0:无校验, 1:奇校验, 2:偶校验 */

/* 数量定义 */
#define DI_CHANNEL_COUNT        8       /* 数字量输入通道数 */
#define PULSE_INPUT_COUNT       4       /* 脉冲计数通道数 */
#define ANALOG_INPUT_COUNT      2       /* 模拟量输入通道数 */
#define INPUT_REG_COUNT         10      /* 输入寄存器数量 (4通道脉冲计数×2 + 2通道模拟量 = 10) */

void portrtu_get_dbg_rx(uint8_t **buf, volatile uint8_t *idx);

/* 函数声明 */
void rtu_slave_init(void);
void rtu_slave_poll(void);
void rtu_slave_print_status(void);  /* 打印当前状态，用于调试 */

/* 数字量输入接口 - 用于读取本地DI状态 */
uint8_t rtu_slave_get_di(uint8_t channel);          /* 获取单个DI通道状态 */
uint16_t rtu_slave_get_di_all(void);                /* 获取所有DI通道状态 (8位) */
uint32_t rtu_slave_get_pulse_count(uint8_t channel); /* 获取脉冲计数值 (0-3通道) */
void rtu_slave_reset_pulse_count(uint8_t channel);  /* 重置脉冲计数器 */

#endif