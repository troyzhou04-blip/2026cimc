#ifndef _USART_DEBUG_H
#define _USART_DEBUG_H

#include "gd32f527.h"

void usart_debug_init(uint32_t baudrate);
void usart_debug_send_byte(uint8_t byte);
void usart_debug_send_string(char *str);

#endif

